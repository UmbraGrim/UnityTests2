﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraPos : MonoBehaviour {

    private Vector3 startPos = new Vector3(4, 7, -1);
    private GameObject curPos;

    [SerializeField]
    private float CamTurnSpeed;
    private float CamMovSpeed;

    private float startTime;
    private float journeyLength;

    public Animator anim;

    private void Awake()
    {
        int numOfCameras = FindObjectsOfType<CameraPos>().Length;
        if(numOfCameras > 1)
        {
            Destroy(gameObject);
        }
        else
        {
            DontDestroyOnLoad(gameObject);
        }

        Transform curPos = gameObject.GetComponent<Transform>();
        startTime = Time.time;
    }

    public void SetWhiteCamPos()
    {
        anim.enabled = false;
        float distMoved = (Time.time - startTime);
        float fracJourney = distMoved / journeyLength;

        //transform.position = Vector3.Lerp(gameObject.transform.position, startPos, fracJourney);
        transform.position = startPos;
        Quaternion target = Quaternion.Euler(60.0f, 0, 0.0f);
        transform.rotation = Quaternion.Slerp(transform.rotation, target, Time.deltaTime * CamTurnSpeed);
    }

    public void SetBlackCamPos()
    {
        transform.position = new Vector3(4.0f, 7.0f, 9.0f);
        Quaternion target = Quaternion.Euler(60.0f, 180.0f, 0.0f);
        transform.rotation = Quaternion.Slerp(transform.rotation, target, Time.deltaTime * CamTurnSpeed);
    }
}
