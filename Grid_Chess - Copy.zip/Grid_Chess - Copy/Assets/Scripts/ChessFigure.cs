﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class ChessFigure : MonoBehaviour {

    public int CurrentX { get; set; }
    public int CurrentY { get; set; }
    public bool isWhite;
    public bool isSelected;
    public bool hasMoved = false;

    public Material wMat;
    public Material bMat;
    
    private Renderer rend;

    private void Awake()
    {
        rend = gameObject.GetComponent<Renderer>();
    }

    public void SetPosition(int x, int y)
    {
        CurrentX = x;
        CurrentY = y;
    }

    public virtual bool[,] PossibleMove()
    {
        return new bool[8, 8];
    }

    public void SetChessPieceColor()
    {
        if (isWhite)
        {
            if (hasMoved)
            {
                rend.material = wMat;
                hasMoved = false;
            }
            else 
            {
                rend.material.color = Color.green;           
            }
        }
        if (!isWhite)
        {
            if (hasMoved)
            {   
                rend.material = bMat;
                hasMoved = false;

            }
            else
            {
                rend.material.color = Color.green;
            }
        }
    }
}
