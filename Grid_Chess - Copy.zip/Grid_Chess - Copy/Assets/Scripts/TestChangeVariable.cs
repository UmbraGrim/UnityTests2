﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestChangeVariable : MonoBehaviour {

    public TestVariableAlteration testVA;

	// Use this for initialization
	void Awake () {
        //testVA = new TestVariableAlteration();
        //testVA = gameObject.AddComponent<TestVariableAlteration>();
	}
	
	// Update is called once per frame
	void Update () {

        if (Input.GetKeyDown("space"))
        {
            //testVA.LetsTest();
        }
        //testVA.HighlightPiece();
	}
}
