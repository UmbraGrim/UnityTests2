﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestVariableAlteration : MonoBehaviour {

    //public bool isACube = true;

    //private Color highlightedColor = Color.green;
    //private Color baseColor = Color.white;
    private float raycastDistance = 100.0f;
    //public Renderer rend;
    //public Vector3 newPos = new Vector3();
    //public Vector3 curPos = new Vector3();
    public GameObject piece;
    public GameObject orig;
    public float xSpeed = 1.0f;
    public bool stop = true;
    public bool BeginMove = false;
    private float startTime;
    private float journeyLength;
    //public float translation;
    public bool isSelected;

    //public Animator anim;
    private int i = 5;
    // Use this for initialization
    void Start () {
        //Animator anim = GetComponent<Animator>();
        startTime = Time.time;

        //journeyLength = Vector3.Distance(orig.position, piece.position);
        journeyLength = Vector3.Distance(orig.transform.position, piece.transform.position);
    }
	
	// Update is called once per frame
	void Update () {
        HighlightPiece();
        ActivateMove();
        //LetsTest
        //StartCoroutine("LetsTestCo");
        //LetsTestLerp();
        if(BeginMove)
        {
            LetsTestLerp();
            //float DistanceToSpace = Vector3.Distance(orig.position, piece.position);
            float DistanceToSpace = Vector3.Distance(orig.transform.position, piece.transform.position);
            if (DistanceToSpace < 0.2f)
            {
                //orig.position = piece.position;
                orig.transform.position = piece.transform.position;
                BeginMove = false;
            }
        }
        /*if (Input.GetKeyDown("k"))
        {
            //LetsTest();
            //StartCoroutine("LetsTestCo");
            
        }*/
        /*if (isSelected == true)
        {
            if (Input.GetMouseButtonDown(0))
            {
                LetsTestLerp();
                Debug.Log("Piece selected");
            }
        }*/

    }

    /*public void LetsTest ()
    { 

        //try coroutine or lerp
        //transform.position = newPos;
        if(Vector3.Distance(transform.position, piece.transform.position) > 0.1f)
        {
            Debug.Log("Script is running");
            transform.Translate(0, 0, xSpeed * Time.deltaTime);
            
        }
        //transform.Translate(newPos * Time.deltaTime);
        //anim.SetBool("HasBeenPressed", true);
        //anim.Play("TestPawnMoveTwo");
    }*/

    IEnumerator LetsTestCo()
    {
        while (stop == true)
        {
            //for (float f = 0.0f; f < 3.0f; f++)
            //{
                transform.Translate(0, 0, xSpeed * Time.deltaTime);
                        // Distance moved = time * speed.
                /*float distCovered = (Time.time - startTime) * xSpeed;

                // Fraction of journey completed = current distance divided by total distance.
                float fracJourney = distCovered / journeyLength;

                // Set our position as a fraction of the distance between the markers.
                transform.position = Vector3.Lerp(orig.position, piece.position, fracJourney);*/
                Debug.Log("Script is running");
                //Debug.Log(f);
                yield return new WaitForSeconds(3.0f);
                stop = false;
                Debug.Log("Script should end");
            //}
        }
    }

    public void LetsTestLerp()
    {
        // Distance moved = time * speed.
        float distCovered = (Time.time - startTime) * xSpeed;

        // Fraction of journey completed = current distance divided by total distance.
        float fracJourney = distCovered / journeyLength;

        // Set our position as a fraction of the distance between the markers.
        //transform.position = Vector3.Lerp(orig.position, piece.position, fracJourney);
        transform.position = Vector3.Lerp(orig.transform.position, piece.transform.position, fracJourney);

    }

    public void HighlightPiece()
    {
        if (!Camera.main) return;
        RaycastHit hit;

        if (Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition),
             out hit, raycastDistance, LayerMask.GetMask("TestPiece")))
        {
            //rend.material.color = highlightedColor;
            isSelected = true;
            Debug.Log("Piece selected");
        }
        else
        {
            isSelected = false;
            //rend.material.color = baseColor;
        }
    }

    public void ActivateMove()
    {
        if(isSelected == true)
        {
            if(Input.GetMouseButton(0))
            {
                BeginMove = true;
            }
        }
    }
}
