﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CreateChessBoard : MonoBehaviour {

    public float[] chessBoardBlack;

    //private List<GameObject> chessBoardBlack = new List<GameObject>();

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    private void SpawnBlackBoard()
    {
        for(int i = 0; i < 33; i++)
        {

        }
    }
    
    private void SpawnWhiteBoard()
    {

    }
}
