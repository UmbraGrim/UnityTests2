﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class AddFeaturesTool : ScriptableWizard {

    public Texture porTexture;
    public Color color = Color.white;
    public string nickname = "Default";
    public MeshRenderer renderObject;
    public MeshFilter meshF;

    [MenuItem("My Tools/Create Feature Filled Object/Create New")]
    static void CreateWizard()
    {
        DisplayWizard<AddFeaturesTool>("Feature Filled Object", "Create New", "Update Existing");
    }

    private void OnWizardCreate()
    {
        GameObject defGO = new GameObject();

        BasicFeatures basFeatures = defGO.AddComponent<BasicFeatures>();
        basFeatures.portrait = porTexture;
        basFeatures.color = color;
        basFeatures.nickname = nickname;
        basFeatures.meshF = meshF;
        basFeatures.meshR = renderObject;

        //put in an error catch, check to see if the selected variables in the tool are null before adding these

        defGO.AddComponent<MeshRenderer>();
        defGO.AddComponent<MeshFilter>();
        Renderer rend = defGO.GetComponent<Renderer>();
        
        rend.material.shader = Shader.Find("color");
        rend.material.SetColor("color", color);
    }

    void OnWizardOtherButton()
    {
        if(Selection.activeTransform != null)
        {
            BasicFeatures basFeatures = Selection.activeTransform.GetComponent<BasicFeatures>();

            if(basFeatures != null)
            {
                basFeatures.portrait = porTexture;
                basFeatures.color = color;
                basFeatures.nickname = nickname;
                basFeatures.portrait = porTexture;
                basFeatures.color = color;
                basFeatures.nickname = nickname;
                basFeatures.meshF = meshF;
                basFeatures.meshR = renderObject;
            }
        }
    }

    private void OnWizardUpdate()
    {
        helpString = "Enter character details";
    }
}
