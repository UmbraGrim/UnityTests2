﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelLoad : MonoBehaviour {

	// Use this for initialization
	void Start () {
        LoadChess();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    private void LoadChess()
    {
        SceneManager.LoadScene(1);
    }
}
