﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BasicFeatures : MonoBehaviour {

    public Texture portrait;
    public Color color;
    public string nickname;
    public MeshRenderer meshR;
    public MeshFilter meshF;


}
