﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RawBishopMovementTest : MonoBehaviour {
    public Animator anim;

    public int x;
    public int z;

    int movTopRight = Animator.StringToHash("MoveForwardRight");
    //int runStateHash = Animator.StringToHash("BaseLayer.Idle");

	// Use this for initialization
	void Start () {
        anim = GetComponent<Animator>();
	}
	
	// Update is called once per frame
	void Update ()
    {
        /*float move = Input.GetAxis("Vertical"); //Input.GetMouseButtonDown(0);
        anim.SetFloat("Speed", move);*/

        //AnimatorStateInfo stateInfo = anim.GetCurrentAnimatorStateInfo(0);
        Move();
    }

    private void Move()
    {
        if (Input.GetKeyDown(KeyCode.K)) //GetMouseButtonDown(0)) //&& stateInfo.nameHash == runStateHash)
        {
            anim.Play("MoveForwardRight");
        }
    }
}
